package net.gfx;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import org.apache.logging.log4j.*;
public class KeyCheck implements KeyListener{
	
	public void keyPressed(KeyEvent Event) {
		
		int keyc = Event.getKeyCode();
		if(keyc == KeyEvent.VK_UP) {
			
		}
}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}
